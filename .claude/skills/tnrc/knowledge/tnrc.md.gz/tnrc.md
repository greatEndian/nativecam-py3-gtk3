# Tool nose radius compensation — local knowledge pack

Compressed and queried offline by `scripts/kb.py`. Sections are `## ` headed;
the query tool prints whole sections, so each one stands alone.

## PROBLEM  why compensation exists at all

A turning insert has no point. Its cutting corner is an arc of radius R, but a
program is written to a single **imaginary tool tip** (also "theoretical tool
tip", "virtual nose position") — the corner the two edges would meet at if the
radius were zero. That is also the point a tool is touched off on: touch a
diameter, touch a face, and the intersection you have set is the imaginary tip.

On a surface **parallel to an axis** the imaginary tip and the real cutting
point coincide in the direction that matters, so an uncompensated program cuts
the right size. On a **taper or an arc** they do not: the nose rides the surface
at a contact point that moves around the arc as the surface angle changes, while
the imaginary tip flies off into the air or digs into the part. The error grows
with R and with how far the surface is from axis-parallel; it peaks at 45°,
where it is R(√2−1) ≈ 0.414 R per side.

Compensation is the correction that puts the *nose*, not the imaginary tip, on
the programmed contour.

## QUADRANTS  the orientation numbers 0-9

The control cannot know where the nose sits relative to the imaginary tip
without being told. That is the **orientation** number — Fanuc calls it T or TIP
in the offset table, LinuxCNC calls it Q in the tool table and L on the G-code
word. It says which way, from the imaginary tip, the centre of the nose circle
lies.

As (X, Z) unit signs, X positive away from the spindle axis and Z positive away
from the chuck:

    1: (+X, -Z)    2: (+X, +Z)    3: (-X, +Z)    4: (-X, -Z)
    5: (-X,  0)    6: ( 0, +Z)    7: (+X,  0)    8: ( 0, -Z)
    9: ( 0,  0)  - the tip IS the nose centre
    0: unspecified / no orientation

1 to 4 are the diagonal quadrants and their raw vector has magnitude **R√2**,
not R. That is a raw vector, not a unit one; normalising it to R·unit is a
classic and expensive mistake, because the diagonal offset really is longer.

**Outside turning uses the +X quadrants**, because the tool approaches the work
from outside and its body lies away from the axis:

    orientation 2  nose centre at +X, +Z   "first quadrant"
    orientation 1  nose centre at +X, -Z   "second quadrant"
    orientation 7  nose centre at +X       straight out, no Z component

Boring and internal work use the −X side: 3, 4, 5.

## OFFSET  the rule, in one line

    control point = surface point + r * normal - R * orientation_vector

- `normal` is the unit normal to the direction of travel, rotated to the side
  compensation is applied to.
- `r` is the nose radius plus any extra allowance being held (a finishing
  stock, a pass offset).
- `R` is the bare nose radius, and `orientation_vector` is the raw table entry
  above.

Two consequences worth having in front of you:

- On a wall **parallel to Z** with an orientation-2 tool the two terms cancel in
  X, so the compensated control point sits on the surface with **no radial
  shift**. Anyone expecting "+R everywhere" will place an entry point 0.4 mm
  wrong on a 0.8 mm nose and wonder why the wall comes out tapered.
- The normal term scales with `r` (radius + allowance) while the orientation
  term scales with the bare `R`. Scaling both by `r` is a different answer
  whenever an allowance is held AND the orientation is diagonal.

## ARCS  what the offset does to a radius

An offset arc is **still an arc, with a different radius**:

    convex  (material outside the arc)   offset radius = R_arc + r
    concave (material inside the arc)    offset radius = R_arc - r

Two failure modes follow directly:

- A **concave corner or fillet smaller than the nose cannot be cut at all**.
  The offset radius goes negative and the path folds back on itself. Controls
  detect this and abort — LinuxCNC says "concave corner cannot be reached
  without gouging". No amount of feed or speed fixes it; the tool is too big.
- On a convex corner the offset path has to travel **around** the vertex on an
  arc of radius `r`, or the two offset segments simply do not meet.

A CAM system that offsets a **flattened** arc — chords rather than the arc
itself — never computes `R ± r`. It gets a polyline that interpolates the true
offset and sits inside it by roughly the chord sagitta. That is bounded and
often fine, but it is a different curve, and the bound must be stated.

## START-UP  where compensation may be switched on

Universal across controls, and the source of most compensation grief:

- The start-up block must be a **straight** move — `G01`, never `G02`/`G03`. An
  arc cannot establish compensation.
- Its length must be **greater than the tool radius**. Shorter and the control
  either refuses or produces nonsense.
- It must be **in free air**. The first compensated move ramps from the
  uncompensated current position to the compensated endpoint, so if that move
  is a cut, the cut surface ramps with it. This is subtle: the program looks
  right, the toolpath looks right, and the part comes out tapered over the
  length of the first segment.
- Cancel with `G40`, and the exit move has the same constraints. On a tight
  bore there may not be room for one, which is a real reason to leave
  compensation off for straight boring.

## LINUXCNC  the specifics for this project

- `G41`/`G42` use the tool table's own radius. `G41.1`/`G42.1 D- L-` are the
  **dynamic** forms: `D` is the tool DIAMETER, `L` the lathe orientation 0-9.
  `L0` gives a pure geometric offset with no orientation term.
- `G40` cancels. Cutter compensation must be off before any plane change
  (G17/G18/G19), or the interpreter errors.
- The lathe works in `G18` (XZ). In canon output for G18, `STRAIGHT_FEED`'s
  first argument is X and its third is Z; `ARC_FEED` is
  `(first_end, second_end, first_axis_centre, second_axis_centre, rotation, ...)`
  = `(z_end, x_end, z_centre, x_centre, rot)`.
- Tool table columns: `D` diameter, `I` front angle, `J` back angle, `Q`
  orientation. **I and J are measured off the perpendicular**, so an edge sits
  at 90 − angle from Z: a J75 insert ramps at 15°.
- `G81`/`G83` drill along the axis normal to the active plane, which in G18 is
  Y. They are therefore useless for lathe drilling along Z; the cycle has to be
  written out.

## NATIVECAM  this project's own contract

Three modes per operation, on a `PARAM_N_COMP` combo threaded as a trailing
`[CALL]` argument: `0` Off, `1` Native LinuxCNC, `2` In CAM.

Globals, all set by `lib/lathe/tip_comp_dia.ngc`:

    #<_tip_comp_d>  D word for G41.1/G42.1 - 2*extra + nose diameter
    #<_tip_comp_l>  L word - the orientation
    #<_tip_lead_w>  nose_dia * #<_diameter_mode> - the minimum radial
                    clearance a comp entry or exit needs
    #<_tip_cam_r>   nose radius for the offset vector
    #<_tip_cam_l>   orientation for the offset vector
    #<_tip_off_z>   } set by tip_comp_vec, the offset to ADD to a
    #<_tip_off_x>   } programmed point, in radius units

Comp side is per operation and **inverted between OD and ID**:

    taper.ngc      (OD)  42, flips to 41 when begin_z LT end_z
    taper_id.ngc         41, flips to 42 when begin_z LT end_z
    boring.ngc           41, flips to 42 when begin_z LT end_z
    facing.ngc           42, flips to 41 when z_factor GT 0
    lathe_poly_pass.ngc  41, 42 when z_dir GT 0, then 83-side for a bore

## MEASURED  numbers from this project, 2026-08-02

Surface left by each mode against the programmed contour, corners excluded,
real nose circle swept along the finish pass:

                       Off      Native    In CAM
    testing_15_2      0.1094    0.0080    0.0080
    testing_11        0.1058    0.0079    0.0079
    testing_13_arcs   0.0013    0.0014    0.0014

Native and In CAM agree to the last digit — two independent implementations of
the same geometry converging. Getting there took two fixes, and both had been
inflating the OTHER mode's apparent error:

- **The arc truncation.** `_min_segment` thinned the contour so no segment was
  shorter than the compensation shrink, keeping only the first and last points
  of the whole contour. A densified arc's last chord is whatever the sweep
  leaves over, so the point where an arc MEETS the next item was dropped and
  the path shortcut the corner. R6, 20 x 4.5° densified, kept every 3rd,
  remainder 0.9423 mm against a 0.960 mm limit — missed by 18 µm and cost
  0.9386 mm of radius. In CAM escaped it only because `build_cam_comp_gcode`
  asks for nose_r 0, which switches the thinning off.
- **The entry ramp.** `lathe_poly_pass` pre-shifted its entry by `comp_r` along
  the plain normal instead of the orientation-aware vector, landing 0.4 mm off
  and making the first CUT the compensation entry move. A wall programmed dead
  straight at r 20.000 came out r 20.4000 at Z+1.0 falling to r 20.0074 at
  Z−20.0.

Method that found both: **generate and parse both sides in one run**, and read
the raw canon rather than a parsed toolpath when the parser itself could be the
suspect.

## SOURCES

- LinuxCNC G-code reference, Tool Compensation and G-codes
  https://linuxcnc.org/docs/html/gcode/tool_compensation.html
  https://linuxcnc.org/docs/html/gcode/g-code.html
- LinuxCNC lathe user manual — orientation diagrams, "FRONTANGLE and BACKANGLE
  are clockwise starting at a line parallel to Z+", and the advice to think of
  the nose radius as a round cutter whose path must not gouge the next line
  https://linuxcnc.org/docs/html/lathe/lathe-user.html
- Cadem, "Tool Nose Radius Compensation in CNC Turning" — imaginary tip, why
  the TTT flies in air or digs in on tapers and radii
  https://cadem.com/wp-content/uploads/2020/09/tool-nose-radius-compensation-tnrc.pdf
- MachMotion, Lathe Tool Nose Radius Compensation — start-up block must be G01,
  movement greater than the nose radius in the R column, no G02/G03
  https://support.machmotion.com/books/cnc-machine-operator-manuals/page/lathe-tool-nose-radius-compensation
- CNC Training Centre, tool nose radius compensation parts 1-2 — tip position
  numbering and where each control keeps it
  https://www.cnctrainingcentre.com/cnc-lathe-tool-nose-radius-compensation-part-2/
- Practical Machinist threads on tool nose comp and tool tip direction — the
  "calculate the TNR centre, then add or subtract one TNR for Z or two radii
  for X" rule of thumb
  https://www.practicalmachinist.com/forum/threads/tool-nose-radius-compensation.276820/
- An offset algorithm for polyline curves, Computers in Industry — raw offset
  generation and global invalid-loop removal
  https://dl.acm.org/doi/abs/10.1016/j.compind.2006.06.002
- Biarc approximation of NURBS curves; one-sided arc approximation of B-spline
  curves for interference-free offsetting — the standard approach of replacing
  a curve's offset with offsets of simple segments under an error bound
  https://www.sciencedirect.com/science/article/abs/pii/S0010448599000196
